package banking;

public class Banking 
{
    public static void main(String[] args)
    {
        bankingclass bank = new bankingclass();
        bank.menu();
    }
}
