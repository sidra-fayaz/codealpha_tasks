package banking;
import java.util.Scanner;
public class bankingclass 
{
    private double balance = 0; 
    public void deposit(double amount
    ) {
        if (amount > 0) 
        {
            balance += amount;
            System.out.println("Deposited: $" + amount);
        } else 
        {
            System.out.println("Invalid deposit amount.");
        }
    }
    public void withdraw(double amount)
    {
        if (amount > 0 && amount <= balance) 
        {
            balance -= amount;
            System.out.println("Withdrawn: $" + amount);
        }
        else if (amount > balance)
        {
            System.out.println("Insufficient balance!");
        } 
        else
        {
            System.out.println("Invalid withdrawal amount.");
        }
    }
    public void checkBalance() 
    {
        System.out.println("Current Balance: $" + balance);
    }
    public void menu() {
        Scanner scan = new Scanner(System.in);
        while (true) {
            System.out.println("\n===== Simple Banking System =====");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit Money");
            System.out.println("3. Withdraw Money");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = scan.nextInt();

            switch (choice) 
            {
                case 1:
                    checkBalance();
                    break;
                case 2:
                    System.out.print("Enter deposit amount: ");
                    double depositAmount = scan.nextDouble();
                    deposit(depositAmount);
                    break;
                case 3:
                    System.out.print("Enter withdrawal amount: ");
                    double withdrawAmount = scan.nextDouble();
                    withdraw(withdrawAmount);
                    break;
                case 4:
                    System.out.println("Thank you for using the banking system!");
                    scan.close();
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }    
    }
}