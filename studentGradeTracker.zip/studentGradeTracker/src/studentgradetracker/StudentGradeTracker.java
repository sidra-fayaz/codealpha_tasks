package studentgradetracker;
import java.util.Scanner;
import java.util.Collections;
import java.util.*;
public class StudentGradeTracker
{
    public static void main(String[] args)
    {
       Scanner scan=new Scanner(System.in);
       ArrayList<Integer> grades = new ArrayList<>();
        System.out.println("Enter student grades (type -1 to stop):");
        while (true) {
            System.out.print("Enter grade: ");
            int grade = scan.nextInt();
            if (grade == -1) break; 
            if (grade < 0 || grade > 100) 
            {
                System.out.println("Invalid grade! Please enter a value between 0 and 100.");
            } 
            else 
            {
                grades.add(grade);
            }
        }
        if (grades.isEmpty()) 
        {
            System.out.println("No grades entered.");
        } 
        else
        {
            int sum = 0;
            for (int grade : grades) 
            {
                sum += grade;
            }
            double average = (double) sum / grades.size();
            int highest = Collections.max(grades);
            int lowest = Collections.min(grades);
            System.out.println("\nResults:");
            System.out.println("Average Grade: " + average);
            System.out.println("Highest Grade: " + highest);
            System.out.println("Lowest Grade: " + lowest);
        } 
    }    
}