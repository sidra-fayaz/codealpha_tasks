package hotel_management;
import java.util.*;
public class customer 
{
    String name;
    String NIC;
    double amount;
    
}
