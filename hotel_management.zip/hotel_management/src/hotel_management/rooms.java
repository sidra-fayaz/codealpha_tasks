package hotel_management;
import java.util.*;
public class rooms 
{
    double roomNo;
    boolean status;
    String category;
    boolean booked;
    double price;
    int sroom,droom,suirooms;
    public rooms()
    {
        this.sroom=this.droom=this.suirooms=10;
    }
    public double getroomNo()
    {
        return (int)((Math.random()*(30-1))+1);
    }
    public double getprice(String category)
    {
        if(category=="SINGLE")
            price = 40000;
        else if(category== "DOUBLE")
            price= 60000;
        else if(category=="SUITE")
            price= 100000;
        return price;
    }
    public void getDate()
    {
        Date d=new Date();
        System.out.println(d);
    }
    public int getrooms(String category)
    {
        int room;
        if(category=="SINGLE")
            room=sroom;
        else if(category=="DOUBLE")  
            room=droom;
        else
            room=suirooms;
        return room;
    }
    public int getPin()
    {
        return (int)(Math.random()*(9999-1000)+1000);
    }
    public double getAmount(String category, double days)
    {
        double amount=getprice(category)*days;
        return amount;
    }
    public void bookRoom(String category)
    {
        if(category=="SINGLE")
        { 
            if(isAvailable(category))
            {
                System.out.println("***ROOM BOOKED***");
                System.out.println("***ENJOY YOUR STAY***");
                sroom--;
            }
            else
                System.out.println("***ROOM IS ALREADY BOOKED***");
        } 
        else if(category=="DOUBLE")
        { 
            if(isAvailable(category))
            {
                System.out.println("***ROOM BOOKED***");
                System.out.println("***ENJOY YOUR STAY***");
                droom--;
            }
            else
                System.out.println("***ROOM IS ALREADY BOOKED***");
        }   
        else if(category=="SUITE")
        { 
            if(isAvailable(category))
            {
                System.out.println("***ROOM BOOKED***");
                System.out.println("***ENJOY YOUR STAY***");
                suirooms--;
            }
            else
                System.out.println("***ROOM IS ALREADY BOOKED***");
        }   
        
    }
    public boolean isAvailable(String category)
    {
        if(category=="SINGLE")
        {
            if(sroom!=0)
            {
                booked=true;
            }
            else
            {
               booked=false;
            }
        }    
        else if(category=="DOUBLE")
        {
            if(droom!=0)
            {
                booked=true;
            }
            else
            {
               booked=false;
            }
        }
        else if(category=="SUITE")
        {
            if(sroom!=0)
            {
                booked=true;
            }
            else
            {
               booked=false;
            }
        }  
        return booked;
    }
}
