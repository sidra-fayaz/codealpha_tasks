package hotel_management;
import java.util.Scanner;
public class Hotel_management
{
    public static void main(String[] args)
    {
        Scanner in=new Scanner(System.in);
        rooms room=new rooms();
        String category=" ";
        System.out.println("ENTER NAME ");
        String name=in.next();
        System.out.println("ENTER DAYS YOU WANT TO STAY");
        double days=in.nextDouble();
        System.out.println("--------------------------------------");
        System.out.println("======================================");
        System.out.println("\tHOTEL MANAGEMENT SYSTEM");
        System.out.println("======================================");
        System.out.println("--------------------------------------");
        System.out.println("THE FOLLOWING TYPES OF ROOMS ARE AVAILABLE");
        System.out.println("1. SINGLE\tPRICE : "+room.getprice("SINGLE")+("\tAVAILABLE ROOMS : ")+ room.getrooms("SINGLE"));
        System.out.println("2. DOUBLE\tPRICE : "+room.getprice("DOUBLE")+("\tAVAILABLE ROOMS : ")+ room.getrooms("DOUBLE"));
        System.out.println("3. SUITE \tPRICE : "+room.getprice("SUITE")+("\tAVAILABLE ROOMS : ")+ room.getrooms("SUITE"));
        System.out.println(" WHICH TYPE OF ROOM DO YOU WANT?");
        int choice= in.nextInt();
            if(choice == 1)
            {
                category="SINGLE";
                room.bookRoom("SINGLE");
                System.out.println("YOUR ROOM NO IS "+ room.getroomNo());
                System.out.println("ROOM PINCODE IS " +room.getPin());
            }
            if(choice == 2)
            {
                category="DOUBLE";
               room.bookRoom("DOUBLE");
               System.out.println("YOUR ROOM NO IS "+ room.getroomNo());
               System.out.println("ROOM PINCODE IS " +room.getPin());
            }
            if(choice == 3)
            {
                category="SUITE";
                room.bookRoom("SUITE");
                System.out.println("YOUR ROOM NO IS "+ room.getroomNo());
                System.out.println("ROOM PINCODE IS " +room.getPin());
            }
        
        System.out.println("***** CUSTOMER RECIEPT *****");
        System.out.println("NAME : "+ name);
        System.out.println("DAYS TO STAY : "+ days);
        System.out.print("CHECKIN DATE : ");
        room.getDate();
        // i have to do a check on price after each selection of room and then show it in reciept
        System.out.println("AMOUNT : " + room.getAmount(category, days));
        System.out.println("THANK YOU FOR USING OUR SERVICE");
        System.out.println("HAVE A NICE STAY");
    }
}